
/**
 * Write a description of interface Carnivore here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Carnivore
{
}
